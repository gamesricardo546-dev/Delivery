import User from "../models/User.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

// LOGIN
export const login = async (req, res) => {
  try {
    const { user, pass } = req.body;

    const dbUser = await User.findOne({ user });

    if (!dbUser) {
      return res.status(401).json({ erro: "Usuário não existe" });
    }

    const valid = await bcrypt.compare(pass, dbUser.pass);

    if (!valid) {
      return res.status(401).json({ erro: "Senha inválida" });
    }

    const token = jwt.sign(
      { id: dbUser._id, user: dbUser.user, role: dbUser.role },
      process.env.JWT_SECRET,
      { expiresIn: "1d" }
    );

    res.json({
      ok: true,
      token,
      user: {
        id: dbUser._id,
        user: dbUser.user,
        role: dbUser.role
      }
    });

  } catch (err) {
    res.status(500).json({ erro: "Erro no login" });
  }
};

// REGISTER (cria admin — protegido por masterKey no body)
export const register = async (req, res) => {
  try {
    const { user, pass, masterKey } = req.body;

    if (masterKey !== process.env.MASTER_KEY) {
      return res.status(403).json({ erro: "Chave mestra inválida" });
    }

    const exists = await User.findOne({ user });
    if (exists) {
      return res.status(400).json({ erro: "Usuário já existe" });
    }

    const hash = await bcrypt.hash(pass, 10);

    const newUser = new User({ user, pass: hash, role: "admin" });
    await newUser.save();

    res.json({ ok: true });

  } catch (err) {
    res.status(500).json({ erro: "Erro ao criar usuário" });
  }
};

// VERIFICAR TOKEN — GET /api/auth/me
export const verificarToken = async (req, res) => {
  try {
    const dbUser = await User.findById(req.user.id).select("-pass");
    if (!dbUser) {
      return res.status(404).json({ erro: "Usuário não encontrado" });
    }
    res.json({ ok: true, user: dbUser });
  } catch (err) {
    res.status(500).json({ erro: "Erro ao verificar token" });
  }
};
