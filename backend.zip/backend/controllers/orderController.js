import Order from "../models/Order.js";

// GET /api/pedidos — listar todos os pedidos (admin)
export const listarPedidos = async (req, res) => {
  try {
    const pedidos = await Order.find()
      .populate("itens.produto", "nome preco")
      .sort({ createdAt: -1 });
    res.json(pedidos);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao listar pedidos" });
  }
};

// GET /api/pedidos/:id — buscar pedido por ID
export const buscarPedido = async (req, res) => {
  try {
    const pedido = await Order.findById(req.params.id).populate("itens.produto", "nome preco");

    if (!pedido) {
      return res.status(404).json({ erro: "Pedido não encontrado" });
    }

    res.json(pedido);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao buscar pedido" });
  }
};

// POST /api/pedidos — criar novo pedido (público — cliente faz o pedido)
export const criarPedido = async (req, res) => {
  try {
    const { nomeCliente, telefone, itens, observacao } = req.body;

    if (!nomeCliente || !itens || itens.length === 0) {
      return res.status(400).json({ erro: "Nome do cliente e itens são obrigatórios" });
    }

    const total = itens.reduce((acc, item) => acc + item.preco * item.quantidade, 0);

    const pedido = new Order({ nomeCliente, telefone, itens, total, observacao });
    await pedido.save();

    res.status(201).json(pedido);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao criar pedido" });
  }
};

// PATCH /api/pedidos/:id/status — atualizar status do pedido (admin)
export const atualizarStatus = async (req, res) => {
  try {
    const { status } = req.body;

    const statusValidos = ["pendente", "em_preparo", "pronto", "entregue", "cancelado"];
    if (!statusValidos.includes(status)) {
      return res.status(400).json({ erro: "Status inválido" });
    }

    const pedido = await Order.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true }
    );

    if (!pedido) {
      return res.status(404).json({ erro: "Pedido não encontrado" });
    }

    res.json(pedido);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao atualizar status" });
  }
};

// DELETE /api/pedidos/:id — remover pedido (admin)
export const deletarPedido = async (req, res) => {
  try {
    const pedido = await Order.findByIdAndDelete(req.params.id);

    if (!pedido) {
      return res.status(404).json({ erro: "Pedido não encontrado" });
    }

    res.json({ ok: true, mensagem: "Pedido removido com sucesso" });
  } catch (err) {
    res.status(500).json({ erro: "Erro ao deletar pedido" });
  }
};
