import Product from "../models/Product.js";

// GET /api/produtos — todos (admin)
export const listarProdutos = async (req, res) => {
  try {
    const produtos = await Product.find().sort({ createdAt: -1 });
    res.json(produtos);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao listar produtos" });
  }
};

// GET /api/produtos/disponiveis — apenas disponíveis (cardápio público)
export const listarProdutosDisponiveis = async (req, res) => {
  try {
    const produtos = await Product.find({ disponivel: true }).sort({ categoria: 1, nome: 1 });
    res.json(produtos);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao listar produtos disponíveis" });
  }
};

// POST /api/produtos — criar produto
export const criarProduto = async (req, res) => {
  try {
    const { nome, descricao, preco, categoria, imagem } = req.body;

    if (!nome || preco == null) {
      return res.status(400).json({ erro: "Nome e preço são obrigatórios" });
    }

    const produto = new Product({ nome, descricao, preco, categoria, imagem });
    await produto.save();

    res.status(201).json(produto);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao criar produto" });
  }
};

// PUT /api/produtos/:id — editar produto
export const atualizarProduto = async (req, res) => {
  try {
    const { nome, descricao, preco, categoria, imagem, disponivel } = req.body;

    const produto = await Product.findByIdAndUpdate(
      req.params.id,
      { nome, descricao, preco, categoria, imagem, disponivel },
      { new: true, runValidators: true }
    );

    if (!produto) {
      return res.status(404).json({ erro: "Produto não encontrado" });
    }

    res.json(produto);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao atualizar produto" });
  }
};

// PATCH /api/produtos/:id/toggle — ativar/desativar
export const toggleDisponibilidade = async (req, res) => {
  try {
    const produto = await Product.findById(req.params.id);

    if (!produto) {
      return res.status(404).json({ erro: "Produto não encontrado" });
    }

    produto.disponivel = !produto.disponivel;
    await produto.save();

    res.json({ ok: true, disponivel: produto.disponivel });
  } catch (err) {
    res.status(500).json({ erro: "Erro ao alterar disponibilidade" });
  }
};

// DELETE /api/produtos/:id — remover produto
export const deletarProduto = async (req, res) => {
  try {
    const produto = await Product.findByIdAndDelete(req.params.id);

    if (!produto) {
      return res.status(404).json({ erro: "Produto não encontrado" });
    }

    res.json({ ok: true, mensagem: "Produto removido com sucesso" });
  } catch (err) {
    res.status(500).json({ erro: "Erro ao deletar produto" });
  }
};
