import mongoose from "mongoose";

const itemSchema = new mongoose.Schema(
  {
    produto: { type: mongoose.Schema.Types.ObjectId, ref: "Product", required: true },
    nome: { type: String, required: true },
    preco: { type: Number, required: true },
    quantidade: { type: Number, required: true, min: 1 },
  },
  { _id: false }
);

const OrderSchema = new mongoose.Schema(
  {
    nomeCliente: { type: String, required: true, trim: true },
    telefone: { type: String, default: "" },
    itens: { type: [itemSchema], required: true },
    total: { type: Number, required: true },
    status: {
      type: String,
      enum: ["pendente", "em_preparo", "pronto", "entregue", "cancelado"],
      default: "pendente",
    },
    observacao: { type: String, default: "" },
  },
  { timestamps: true }
);

export default mongoose.model("Order", OrderSchema);
