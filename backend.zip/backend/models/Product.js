import mongoose from "mongoose";

const ProductSchema = new mongoose.Schema(
  {
    nome: { type: String, required: true, trim: true },
    descricao: { type: String, default: "" },
    preco: { type: Number, required: true, min: 0 },
    categoria: { type: String, default: "Geral" },
    imagem: { type: String, default: "" }, // URL ou base64
    disponivel: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export default mongoose.model("Product", ProductSchema);
