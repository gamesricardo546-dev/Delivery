import mongoose from "mongoose";

export let dbConnected = true;

export const connectDB = async () => {
  if (!process.env.MONGO_URI) {
    console.warn("[AVISO] MONGO_URI nao definida no .env — servidor iniciando SEM banco de dados.");
    console.warn("[AVISO] As rotas da API vao retornar erro 500 ate voce configurar o MongoDB.");
    return;
  }

  try {
    // Corrige URIs do Atlas que vem com parametro invalido "?=Cluster0"
    let uri = process.env.MONGO_URI;
    if (uri.includes("?=")) {
      uri = uri.replace(/\?=(\w+)/, "?retryWrites=true&w=majority&appName=$1");
    }
    await mongoose.connect(uri);
    dbConnected = true;
    console.log("MongoDB conectado com sucesso");
  } catch (err) {
    console.error("Erro ao conectar no MongoDB:", err.message);
    console.warn("[AVISO] Servidor iniciando SEM banco de dados.");
  }
};