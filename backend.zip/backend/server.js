import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import { connectDB } from "./config/db.js";

import authRoutes    from "./routes/authRoutes.js";
import productRoutes from "./routes/productRoutes.js";
import orderRoutes   from "./routes/orderRoutes.js";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);

const app = express();

// ── MIDDLEWARES GLOBAIS ───────────────────────────────────────────────────────

app.use(cors({
  origin: "*",
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE"],
  allowedHeaders: ["Content-Type", "Authorization"],
}));

app.use(express.json({ limit: "10mb" }));

// ── ARQUIVOS ESTÁTICOS (frontend) ─────────────────────────────────────────────
app.use(express.static(path.join(__dirname, "public")));

// ── ROTAS DA API ──────────────────────────────────────────────────────────────

app.use("/api/auth",     authRoutes);
app.use("/api/produtos", productRoutes);
app.use("/api/pedidos",  orderRoutes);

app.get("/api/health", (req, res) => {
  res.json({ ok: true, message: "Servidor rodando" });
});

// ── INICIALIZAÇÃO ─────────────────────────────────────────────────────────────

const PORT = process.env.PORT || 3000;

connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
  });
});