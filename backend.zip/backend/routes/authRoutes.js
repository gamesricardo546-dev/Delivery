import express from "express";
import { login, register, verificarToken } from "../controllers/authController.js";
import { auth } from "../middleware/authMiddleware.js";

const router = express.Router();

// POST /api/auth/login — login do admin
router.post("/login", login);

// POST /api/auth/register — cria novo admin (protegido por masterKey no body)
router.post("/register", register);

// GET /api/auth/me — verifica se o token ainda é válido
router.get("/me", auth, verificarToken);

export default router;