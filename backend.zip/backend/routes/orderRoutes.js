import express from "express";
import {
  listarPedidos,
  buscarPedido,
  criarPedido,
  atualizarStatus,
  deletarPedido,
} from "../controllers/orderController.js";
import { auth, adminOnly } from "../middleware/authMiddleware.js";

const router = express.Router();

// ── ROTAS PÚBLICAS ────────────────────────────────────────────────────────────

// POST /api/pedidos — cliente cria um pedido
router.post("/", criarPedido);

// ── ROTAS PRIVADAS (exige token de admin) ─────────────────────────────────────

// GET /api/pedidos — lista todos os pedidos
router.get("/", auth, adminOnly, listarPedidos);

// GET /api/pedidos/:id — busca pedido específico
router.get("/:id", auth, adminOnly, buscarPedido);

// PATCH /api/pedidos/:id/status — atualiza status
router.patch("/:id/status", auth, adminOnly, atualizarStatus);

// DELETE /api/pedidos/:id — remove pedido
router.delete("/:id", auth, adminOnly, deletarPedido);

export default router;
