import express from "express";
import {
  listarProdutos,
  listarProdutosDisponiveis,
  criarProduto,
  atualizarProduto,
  toggleDisponibilidade,
  deletarProduto,
} from "../controllers/productController.js";
import { auth, adminOnly } from "../middleware/authMiddleware.js";

const router = express.Router();

// ── ROTAS PÚBLICAS (sem token) ───────────────────────────────────────────────

// GET /api/produtos — todos os produtos (para o admin ver tudo)
router.get("/", listarProdutos);

// GET /api/produtos/disponiveis — apenas produtos disponíveis (para o cardápio)
router.get("/disponiveis", listarProdutosDisponiveis);

// ── ROTAS PRIVADAS (exige token de admin) ────────────────────────────────────

// POST /api/produtos — cria produto
router.post("/", auth, adminOnly, criarProduto);

// PUT /api/produtos/:id — edita produto
router.put("/:id", auth, adminOnly, atualizarProduto);

// PATCH /api/produtos/:id/toggle — ativa/desativa produto
router.patch("/:id/toggle", auth, adminOnly, toggleDisponibilidade);

// DELETE /api/produtos/:id — remove produto
router.delete("/:id", auth, adminOnly, deletarProduto);

export default router;